'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { getPacientes, deletePaciente, type Paciente } from '@/lib/supabase'
import { calcIdadeAnos } from '@/lib/who'
import { UserPlus, Trash2, ChevronRight, Activity } from 'lucide-react'

function idadeStr(dataNasc: string) {
  const anos = calcIdadeAnos(dataNasc)
  if (anos < 2) return `${Math.round(anos * 12)} meses`
  return `${Math.floor(anos)} anos`
}

export default function Home() {
  const [pacientes, setPacientes] = useState<Paciente[]>([])
  const [loading, setLoading]     = useState(true)
  const [busca, setBusca]         = useState('')
  const [deletando, setDeletando] = useState<string | null>(null)

  useEffect(() => { load() }, [])

  async function load() {
    setLoading(true)
    try { setPacientes(await getPacientes()) } finally { setLoading(false) }
  }

  async function handleDelete(id: string, nome: string) {
    if (!confirm(`Remover ${nome} e todas as medições? Esta ação não pode ser desfeita.`)) return
    setDeletando(id)
    try { await deletePaciente(id); setPacientes(p => p.filter(x => x.id !== id)) }
    finally { setDeletando(null) }
  }

  const filtrados = pacientes.filter(p =>
    p.nome.toLowerCase().includes(busca.toLowerCase())
  )

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-stone-100 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="text-brand-500" size={22} />
            <span className="font-semibold text-lg tracking-tight">NutriCurvas</span>
          </div>
          <Link
            href="/pacientes/novo"
            className="flex items-center gap-1.5 bg-brand-500 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-brand-600"
          >
            <UserPlus size={15} />
            Novo paciente
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        {/* Search */}
        <input
          type="search"
          placeholder="Buscar paciente..."
          value={busca}
          onChange={e => setBusca(e.target.value)}
          className="w-full mb-6 text-base"
        />

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          <div className="bg-white border border-stone-100 rounded-xl p-4">
            <p className="text-xs text-stone-400 mb-1">Total de pacientes</p>
            <p className="text-3xl font-semibold text-brand-600">{pacientes.length}</p>
          </div>
          <div className="bg-white border border-stone-100 rounded-xl p-4">
            <p className="text-xs text-stone-400 mb-1">Resultado da busca</p>
            <p className="text-3xl font-semibold text-stone-700">{filtrados.length}</p>
          </div>
        </div>

        {/* List */}
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="bg-white border border-stone-100 rounded-xl p-4 animate-pulse">
                <div className="h-4 bg-stone-100 rounded w-1/3 mb-2" />
                <div className="h-3 bg-stone-100 rounded w-1/4" />
              </div>
            ))}
          </div>
        ) : filtrados.length === 0 ? (
          <div className="text-center py-20 text-stone-400">
            <UserPlus size={40} className="mx-auto mb-3 opacity-30" />
            <p className="font-medium">{busca ? 'Nenhum paciente encontrado' : 'Nenhum paciente cadastrado'}</p>
            {!busca && (
              <Link href="/pacientes/novo" className="mt-3 inline-block text-brand-500 text-sm hover:underline">
                Cadastrar primeiro paciente →
              </Link>
            )}
          </div>
        ) : (
          <ul className="space-y-2">
            {filtrados.map(p => (
              <li key={p.id} className="bg-white border border-stone-100 rounded-xl hover:border-brand-200 hover:shadow-sm transition group">
                <div className="flex items-center">
                  <Link href={`/pacientes/${p.id}`} className="flex-1 flex items-center gap-4 p-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0 ${p.sexo === 'M' ? 'bg-blue-50 text-blue-600' : 'bg-pink-50 text-pink-600'}`}>
                      {p.nome.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-stone-800 truncate">{p.nome}</p>
                      <p className="text-xs text-stone-400 mt-0.5">
                        {p.sexo === 'M' ? 'Masculino' : 'Feminino'} · {idadeStr(p.data_nascimento)}
                      </p>
                    </div>
                    <ChevronRight size={16} className="text-stone-300 group-hover:text-brand-400 transition" />
                  </Link>
                  <button
                    onClick={() => handleDelete(p.id, p.nome)}
                    disabled={deletando === p.id}
                    className="p-4 text-stone-300 hover:text-red-400 disabled:opacity-50"
                    title="Remover paciente"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  )
}
